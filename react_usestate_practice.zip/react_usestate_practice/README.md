# React useState Practice

## Run in VS Code
1. Extract the ZIP.
2. Open the `react_usestate_practice` folder in VS Code.
3. Open Terminal > New Terminal.
4. Run:
   ```bash
   npm install
   npm run dev
   ```
5. Open the local URL shown in the terminal (usually http://localhost:5173).

The page includes an increment/reset counter and a show/hide student details example.
Run commands in the folder containing `package.json`. Node.js must be installed.
