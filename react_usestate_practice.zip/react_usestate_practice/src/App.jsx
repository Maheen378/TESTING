import Navbar from "./components/Navbar.jsx";
import Counter from "./components/Counter.jsx";
import StudentDetails from "./components/StudentDetails.jsx";

export default function App() {
  return (
    <>
      <Navbar />
      <main className="container py-5">
        <div className="text-center mb-5">
          <span className="badge text-bg-primary mb-3">React + Bootstrap</span>
          <h1 className="fw-bold">useState Practice</h1>
          <p className="text-secondary">Practise two common exam questions: increment a number and show details.</p>
        </div>
        <div className="row g-4">
          <div className="col-12 col-lg-6"><Counter /></div>
          <div className="col-12 col-lg-6"><StudentDetails /></div>
        </div>
        <div className="alert alert-info mt-4 mb-0"><strong>Exam tip:</strong> useState stores a value. Calling its setter function updates the page.</div>
      </main>
      <footer className="text-center py-3 border-top text-secondary">React useState Exam Practice</footer>
    </>
  );
}
