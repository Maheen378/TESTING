import { useState } from "react";

export default function Counter() {
  const [count, setCount] = useState(0);

  return (
    <section className="card h-100 shadow-sm">
      <div className="card-body p-4 text-center">
        <h2 className="h4 card-title">1. Counter</h2>
        <p className="text-secondary">Click the button to increment the number.</p>
        <div className="display-3 fw-bold my-4" aria-live="polite">{count}</div>
        <div className="d-flex justify-content-center gap-2">
          <button className="btn btn-primary" onClick={() => setCount(count + 1)}>+1 Increment</button>
          <button className="btn btn-outline-secondary" onClick={() => setCount(0)}>Reset</button>
        </div>
      </div>
    </section>
  );
}
