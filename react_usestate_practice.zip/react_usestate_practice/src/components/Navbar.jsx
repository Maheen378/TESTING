export default function Navbar() {
  return (
    <nav className="navbar navbar-dark bg-dark">
      <div className="container">
        <a className="navbar-brand fw-bold" href="/">React Practice</a>
        <span className="navbar-text text-light">Exam Preparation</span>
      </div>
    </nav>
  );
}
