import { useState } from "react";

export default function StudentDetails() {
  const [showDetails, setShowDetails] = useState(false);

  return (
    <section className="card h-100 shadow-sm">
      <div className="card-body p-4">
        <h2 className="h4 card-title">2. Student Details</h2>
        <p className="text-secondary">Click the button to show or hide the student's email and phone number.</p>
        <div className="bg-light rounded p-3 mb-3">
          <h3 className="h5 mb-1">Maheen</h3>
          <p className="text-secondary mb-0">Software Engineering Student</p>
        </div>
        <button className="btn btn-success" onClick={() => setShowDetails(!showDetails)} aria-expanded={showDetails}>
          {showDetails ? "Hide Details" : "Show Details"}
        </button>
        {showDetails && (
          <div className="alert alert-success mt-3 mb-0">
            <p className="mb-1"><strong>Email:</strong> maheen@example.com</p>
            <p className="mb-0"><strong>Phone:</strong> 0300-1234567</p>
          </div>
        )}
      </div>
    </section>
  );
}
